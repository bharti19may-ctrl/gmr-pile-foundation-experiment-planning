from __future__ import annotations

import csv
import hashlib
import json
import math
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
INPUTS = ROOT / "data" / "inputs"
RESULTS = ROOT / "data" / "results"
MANIFEST = ROOT / "MANIFEST_SHA256.txt"

REQUIRED_INPUTS = {
    "component_feature_matrix_81.csv",
    "dynamic_response_matrix.csv",
    "stmoi_weight_sensitivity.csv",
}

REQUIRED_RESULTS = {
    "beam_boundary_soil_parameters.csv",
    "beam_boundary_soil_sensitivity.csv",
    "beam_boundary_soil_summary.csv",
    "beam_winkler_modal_comparison.csv",
    "beam_winkler_parameters.csv",
    "beam_winkler_rank_summary.csv",
    "cap_mass_parameters.csv",
    "cap_mass_sensitivity.csv",
    "cap_mass_sensitivity_summary.csv",
    "common_pga_scaled_ranking.csv",
    "common_pga_scaling_summary.csv",
    "component_dependence_diagnostics.csv",
    "fixed_head_stress_sensitivity.csv",
    "dynamic_maxima_by_damping.csv",
    "governing_nonlinear_analysis.csv",
    "hierarchical_bootstrap_rho.csv",
    "hierarchical_bootstrap_summary.csv",
    "illustrative_nonlinear_py_sensitivity.csv",
    "illustrative_nonlinear_py_summary.csv",
    "joint_uncertainty_samples.csv",
    "joint_uncertainty_summary.csv",
    "leave_one_event_out_validation.csv",
    "orientation_factor_sensitivity.csv",
    "ranked_multimodel_suite.csv",
    "sensor_transfer_function_sensitivity.csv",
    "sensor_transfer_weighted_bands.csv",
    "analysis_summary.csv",
    "table_s1_component_inventory_81.csv",
}


def read_csv(path):
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def finite(value):
    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError):
        return False


def sha256(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_manifest():
    entries = {}
    if not MANIFEST.is_file():
        return entries
    for line in MANIFEST.read_text(encoding="utf-8").splitlines():
        if not line or line.startswith("#"):
            continue
        digest, size, relative = line.split("  ", 2)
        entries[relative] = {"sha256": digest, "size": int(size)}
    return entries


def main():
    failures = []
    input_names = {path.name for path in INPUTS.glob("*.csv")}
    result_names = {path.name for path in RESULTS.glob("*.csv")}
    if missing := sorted(REQUIRED_INPUTS - input_names):
        failures.append({"check": "required inputs", "missing": missing})
    if missing := sorted(REQUIRED_RESULTS - result_names):
        failures.append({"check": "required results", "missing": missing})

    features = read_csv(INPUTS / "component_feature_matrix_81.csv")
    feature_keys = [
        (row["event_id"], row["station"], row["component"]) for row in features
    ]
    required_numeric = ["pga_g", "rms_g", "cav_g_s", "arias_m_s", "d5_95_s", "stmoi"]
    absolute_paths = [
        row.get("csv_file", "")
        for row in features
        if re.match(r"^[A-Za-z]:[\\/]", row.get("csv_file", ""))
    ]
    if len(features) != 81:
        failures.append({"check": "feature row count", "observed": len(features), "expected": 81})
    if len(set(feature_keys)) != len(feature_keys):
        failures.append({"check": "unique event-station-component key"})
    if absolute_paths:
        failures.append({"check": "portable waveform paths", "count": len(absolute_paths)})
    invalid_numeric = sum(
        not finite(row.get(column)) for row in features for column in required_numeric
    )
    if invalid_numeric:
        failures.append({"check": "finite required feature variables", "count": invalid_numeric})

    dynamic = read_csv(INPUTS / "dynamic_response_matrix.csv")
    dynamic_keys = {
        (row["event_id"], row["station"], row["component"]) for row in dynamic
    }
    if dynamic_keys != set(feature_keys):
        failures.append(
            {
                "check": "dynamic/feature key coverage",
                "missing_dynamic_keys": len(set(feature_keys) - dynamic_keys),
                "extra_dynamic_keys": len(dynamic_keys - set(feature_keys)),
            }
        )

    inventory = read_csv(
        RESULTS / "table_s1_component_inventory_81.csv"
    )
    if len(inventory) != 81:
        failures.append({"check": "Table S1 row count", "observed": len(inventory), "expected": 81})

    manifest = load_manifest()
    for relative, expected in manifest.items():
        path = ROOT / relative
        if not path.is_file():
            failures.append({"check": "manifest file exists", "path": relative})
            continue
        if path.stat().st_size != expected["size"] or sha256(path) != expected["sha256"]:
            failures.append({"check": "manifest integrity", "path": relative})

    report = {
        "status": "PASS" if not failures else "FAIL",
        "feature_rows": len(features),
        "unique_component_keys": len(set(feature_keys)),
        "events": len({row["event_id"] for row in features}),
        "event_station_pairs": len({(row["event_id"], row["station"]) for row in features}),
        "dynamic_rows": len(dynamic),
        "dynamic_component_keys": len(dynamic_keys),
        "result_csv_files": len(result_names),
        "manifest_entries_checked": len(manifest),
        "failures": failures,
    }
    print(json.dumps(report, indent=2))
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.exit(main())
