from __future__ import annotations

from pathlib import Path
import math
import os

import numpy as np
import pandas as pd


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
INPUT_DIR = PACKAGE_ROOT / "data" / "inputs"
DATA_DIR = PACKAGE_ROOT / "data" / "reproduced_results"
DATA_DIR.mkdir(parents=True, exist_ok=True)
WAVEFORM_ROOT = Path(
    os.environ.get("CESMD_WAVEFORM_ROOT", PACKAGE_ROOT / "data" / "waveforms")
)

FEATURE_FILE = INPUT_DIR / "component_feature_matrix_81.csv"
DYNAMIC_FILE = INPUT_DIR / "dynamic_response_matrix.csv"
WEIGHT_FILE = INPUT_DIR / "stmoi_weight_sensitivity.csv"

ES_PA = 200.0e9
YS_M = 0.12
FY_MPA = 415.0
KAPPA_Y_1_M = FY_MPA * 1.0e6 / (ES_PA * YS_M)
R_VALUES = [1.5, 2.0, 2.5, 3.0, 3.5]
DAMPING_VALUES = [0.05, 0.10, 0.15]

BASE_WEIGHTS = {
    "pga_g_norm": 0.25,
    "rms_g_norm": 0.20,
    "cav_g_s_norm": 0.15,
    "arias_m_s_norm": 0.15,
    "d5_95_s_norm": 0.10,
    "sensor_band": 0.10,
    "component_factor": 0.05,
}

KEYS = ["event_id", "station", "component"]


def record_value(record, name):
    if hasattr(record, name):
        return getattr(record, name)
    return record[name]


def waveform_path(record):
    relative = Path(str(record_value(record, "csv_file")))
    candidates = [PACKAGE_ROOT / relative]
    candidates.append(
        WAVEFORM_ROOT
        / str(record_value(record, "event_id"))
        / str(record_value(record, "station"))
        / relative.name
    )
    for candidate in candidates:
        if candidate.is_file():
            return candidate
    raise FileNotFoundError(
        "Required CESMD waveform not found. Download the processed record and place it at "
        f"{candidates[0]}, or set CESMD_WAVEFORM_ROOT to a directory containing the "
        "event/station/file hierarchy described in README.txt."
    )


def read_waveform(record):
    return pd.read_csv(waveform_path(record))


def spearman(a, b):
    return float(pd.Series(a).rank(method="average").corr(pd.Series(b).rank(method="average")))


def score_frame(frame, horizontal_factor=0.9, band=None, renormalize=False):
    work = frame.copy()
    if renormalize:
        for raw in ["pga_g", "rms_g", "cav_g_s", "arias_m_s", "d5_95_s"]:
            denom = float(work[raw].max())
            work[raw + "_norm"] = work[raw] / denom if denom else 0.0
    work["component_factor"] = np.where(work["orientation"].eq("Vertical"), 1.0, horizontal_factor)
    work["sensor_band"] = work["sensor_band_0p5_15_fraction"] if band is None else np.asarray(band)
    work["score"] = sum(BASE_WEIGHTS[name] * work[name] for name in BASE_WEIGHTS)
    return work


def fixed_head_response(dynamic, feat):
    maxima = (
        dynamic.groupby(KEYS + ["damping_ratio"], as_index=False)
        .agg(
            max_relative_displacement_m=("max_relative_displacement_m", "max"),
            controlling_frequency_hz=("max_relative_displacement_m", lambda s: float(dynamic.loc[s.idxmax(), "frequency_hz"])),
        )
    )
    maxima = maxima.merge(feat[KEYS + ["orientation", "pga_g", "stmoi", "sensor_band_0p5_15_fraction"]], on=KEYS)
    rows = []
    for rec in maxima.itertuples(index=False):
        for active_length in R_VALUES:
            # R=(4EI/k)^(1/4) is the inverse Winkler decay parameter. For a
            # rotation-restrained head, kappa(0)=2u(0)/R^2.
            curvature = 2.0 * rec.max_relative_displacement_m / active_length**2
            stress_mpa = ES_PA * YS_M * curvature / 1.0e6
            rows.append(
                {
                    **{key: getattr(rec, key) for key in KEYS},
                    "orientation": rec.orientation,
                    "pga_g": rec.pga_g,
                    "stmoi": rec.stmoi,
                    "sensor_band_fraction": rec.sensor_band_0p5_15_fraction,
                    "damping_ratio": rec.damping_ratio,
                    "active_length_m": active_length,
                    "controlling_frequency_hz": rec.controlling_frequency_hz,
                    "max_relative_displacement_m": rec.max_relative_displacement_m,
                    "curvature_1_m": curvature,
                    "yield_curvature_1_m": KAPPA_Y_1_M,
                    "curvature_ductility": curvature / KAPPA_Y_1_M,
                    "gmr_elastic_range_index": rec.sensor_band_0p5_15_fraction
                    * min(curvature / KAPPA_Y_1_M, 1.0),
                    "nonlinear_flag": int(curvature / KAPPA_Y_1_M > 1.0),
                    "elastic_predictor_mpa_equiv": stress_mpa,
                    "yield_ratio": stress_mpa / FY_MPA,
                    "nonlinear_follow_up": "Mandatory" if stress_mpa > FY_MPA else "Not triggered by yield screen",
                }
            )
    out = pd.DataFrame(rows)
    out.to_csv(DATA_DIR / "fixed_head_stress_sensitivity.csv", index=False)
    maxima.to_csv(DATA_DIR / "dynamic_maxima_by_damping.csv", index=False)
    return out, maxima


def leave_one_event_out(feat):
    base = score_frame(feat, 0.9)
    rows = []
    for event in sorted(feat.event_id.unique()):
        remaining = feat.loc[feat.event_id.ne(event)].copy()
        recalculated = score_frame(remaining, 0.9, renormalize=True)
        base_remaining = base.loc[base.event_id.ne(event)].copy()
        joined = base_remaining[KEYS + ["score"]].merge(
            recalculated[KEYS + ["score"]], on=KEYS, suffixes=("_full", "_blocked")
        )
        top_full = set(map(tuple, joined.nlargest(10, "score_full")[KEYS].to_numpy()))
        top_blocked = set(map(tuple, joined.nlargest(10, "score_blocked")[KEYS].to_numpy()))
        rows.append(
            {
                "omitted_event": event,
                "remaining_components": len(joined),
                "spearman_rho": spearman(joined.score_full, joined.score_blocked),
                "top10_overlap": len(top_full & top_blocked),
                "top_record_stable": joined.nlargest(1, "score_full")[KEYS].iloc[0].tolist()
                == joined.nlargest(1, "score_blocked")[KEYS].iloc[0].tolist(),
            }
        )
    out = pd.DataFrame(rows)
    out.to_csv(DATA_DIR / "leave_one_event_out_validation.csv", index=False)
    return out


def one_way_icc(values, clusters):
    frame = pd.DataFrame({"value": np.asarray(values, float), "cluster": np.asarray(clusters)})
    groups = list(frame.groupby("cluster"))
    n = len(frame)
    j = len(groups)
    grand = frame.value.mean()
    sizes = np.array([len(g) for _, g in groups], float)
    ss_between = sum(len(g) * (g.value.mean() - grand) ** 2 for _, g in groups)
    ss_within = sum(((g.value - g.value.mean()) ** 2).sum() for _, g in groups)
    ms_between = ss_between / max(j - 1, 1)
    ms_within = ss_within / max(n - j, 1)
    n0 = (n - (sizes**2).sum() / n) / max(j - 1, 1)
    denominator = ms_between + (n0 - 1.0) * ms_within
    icc = (ms_between - ms_within) / denominator if denominator else 0.0
    mean_cluster = sizes.mean()
    effective_n = n / (1.0 + (mean_cluster - 1.0) * max(icc, 0.0))
    return float(icc), float(effective_n), float(mean_cluster), j


def dependence_diagnostics(feat):
    rows = []
    for label, clusters in [
        ("Event", feat.event_id),
        ("Event-station", feat.event_id.astype(str) + "/" + feat.station.astype(str)),
    ]:
        for metric in ["stmoi", "pga_g", "sensor_band_0p5_15_fraction"]:
            icc, neff, mean_size, count = one_way_icc(feat[metric], clusters)
            rows.append(
                {
                    "cluster_level": label,
                    "metric": metric,
                    "cluster_count": count,
                    "mean_cluster_size": mean_size,
                    "icc_1": icc,
                    "effective_n": neff,
                }
            )
    out = pd.DataFrame(rows)
    out.to_csv(DATA_DIR / "component_dependence_diagnostics.csv", index=False)
    return out


def orientation_sensitivity(feat):
    base = score_frame(feat, 0.9)
    base_top10 = set(map(tuple, base.nlargest(10, "score")[KEYS].to_numpy()))
    rows = []
    for horizontal_factor in [0.95, 0.90, 0.80, 0.00]:
        scenario = score_frame(feat, horizontal_factor)
        top10 = set(map(tuple, scenario.nlargest(10, "score")[KEYS].to_numpy()))
        rows.append(
            {
                "vertical_factor": 1.0,
                "horizontal_factor": horizontal_factor,
                "maximum_orientation_contribution_difference": 0.05 * (1.0 - horizontal_factor),
                "spearman_rho_vs_base": spearman(base.score, scenario.score),
                "top10_overlap": len(base_top10 & top10),
                "top_record": "/".join(scenario.nlargest(1, "score")[KEYS].iloc[0].astype(str)),
            }
        )
    out = pd.DataFrame(rows)
    out.to_csv(DATA_DIR / "orientation_factor_sensitivity.csv", index=False)
    return out


def transfer_function_sensitivity(feat):
    scenario_names = [
        "Rectangular 0.5-15 Hz",
        "First-order 0.5-15 Hz",
        "First-order 1-10 Hz",
        "First-order 2-8 Hz",
        "NVE AAH002-02E + provisional DAQ 0.5-20 Hz",
    ]
    bands = {name: [] for name in scenario_names}
    for rec in feat.itertuples(index=False):
        source = read_waveform(rec)
        t = source.time_s.to_numpy(float)
        x = source.acc_g.to_numpy(float) - source.acc_g.mean()
        dt = float(np.median(np.diff(t)))
        f = np.fft.rfftfreq(len(x), dt)
        power = np.abs(np.fft.rfft(x)) ** 2
        denom = max(float(power.sum()), np.finfo(float).eps)
        rect = ((f >= 0.5) & (f <= 15.0)).astype(float)

        def first_order(f_low, f_high):
            hp = np.divide(f, f_low, out=np.zeros_like(f), where=f_low != 0) / np.sqrt(1.0 + (f / f_low) ** 2)
            lp = 1.0 / np.sqrt(1.0 + (f / f_high) ** 2)
            return hp * lp

        def commercial_reference_chain():
            # NVE specifies DC to >1 MHz sensor response, so the planned
            # conditioner and anti-alias filter dominate the seismic band.
            hp = f / np.sqrt(f**2 + 0.5**2)
            lp4 = 1.0 / np.sqrt(1.0 + (f / 20.0) ** 8)
            return hp * lp4

        responses = [
            rect,
            first_order(0.5, 15.0),
            first_order(1.0, 10.0),
            first_order(2.0, 8.0),
            commercial_reference_chain(),
        ]
        for name, response in zip(scenario_names, responses):
            bands[name].append(float(np.sum(power * response**2) / denom))

    base = score_frame(feat, 0.9, bands[scenario_names[0]])
    base_top10 = set(map(tuple, base.nlargest(10, "score")[KEYS].to_numpy()))
    rows = []
    detail = feat[KEYS].copy()
    for name in scenario_names:
        scenario = score_frame(feat, 0.9, bands[name])
        detail[name] = bands[name]
        top10 = set(map(tuple, scenario.nlargest(10, "score")[KEYS].to_numpy()))
        rows.append(
            {
                "transfer_function": name,
                "median_weighted_energy_fraction": float(np.median(bands[name])),
                "spearman_rho_vs_rectangular_base": spearman(base.score, scenario.score),
                "top10_overlap": len(base_top10 & top10),
                "top_record": "/".join(scenario.nlargest(1, "score")[KEYS].iloc[0].astype(str)),
            }
        )
    summary = pd.DataFrame(rows)
    summary.to_csv(DATA_DIR / "sensor_transfer_function_sensitivity.csv", index=False)
    detail.to_csv(DATA_DIR / "sensor_transfer_weighted_bands.csv", index=False)
    return summary, detail


def supplementary_component_inventory(feat):
    event_names = {
        "ak0219neiszm": "2021 Chignik",
        "us6000jllz": "2023 Pazarcik-Turkiye",
        "us6000t04s": "Event Mw 6.9",
        "us7000pn9s": "2025 Mandalay",
        "us7000qd1y": "Event Mw 7.3",
    }
    event_magnitudes = {
        "ak0219neiszm": 8.2,
        "us6000jllz": 7.8,
        "us6000t04s": 6.9,
        "us7000pn9s": 7.7,
        "us7000qd1y": 7.3,
    }
    columns = [
        "event_id", "station", "component", "orientation", "npts",
        "sample_rate_hz", "duration_s", "pga_g", "rms_g", "cav_g_s",
        "arias_m_s", "d5_95_s", "dominant_frequency_hz",
        "spectral_centroid_hz", "sensor_band_0p5_15_fraction", "stmoi",
    ]
    out = feat[columns].copy()
    out.insert(1, "event_name", out.event_id.map(event_names))
    out.insert(2, "moment_magnitude_mw", out.event_id.map(event_magnitudes))
    out = out.rename(columns={"station": "station_id"})
    out = out.sort_values(["event_id", "station_id", "component"])
    out.to_csv(DATA_DIR / "table_s1_component_inventory_81.csv", index=False)
    return out


def build_beam_winkler_modes(cap_mass=10000.0):
    pile_length = 10.0
    diameter = 0.24
    young = ES_PA
    density = 7850.0
    active_length = 2.5
    elements = 20
    modes_retained = 3
    area = math.pi * diameter**2 / 4.0
    inertia = math.pi * diameter**4 / 64.0
    ei = young * inertia
    foundation_modulus = 4.0 * ei / active_length**4
    mass_per_length = density * area
    le = pile_length / elements
    ndof = 2 * (elements + 1)
    K = np.zeros((ndof, ndof))
    M = np.zeros((ndof, ndof))
    kb = ei / le**3 * np.array(
        [[12, 6 * le, -12, 6 * le], [6 * le, 4 * le**2, -6 * le, 2 * le**2],
         [-12, -6 * le, 12, -6 * le], [6 * le, 2 * le**2, -6 * le, 4 * le**2]], float
    )
    shape_integral = le / 420.0 * np.array(
        [[156, 22 * le, 54, -13 * le], [22 * le, 4 * le**2, 13 * le, -3 * le**2],
         [54, 13 * le, 156, -22 * le], [-13 * le, -3 * le**2, -22 * le, 4 * le**2]], float
    )
    for element in range(elements):
        dofs = [2 * element, 2 * element + 1, 2 * element + 2, 2 * element + 3]
        K[np.ix_(dofs, dofs)] += kb + foundation_modulus * shape_integral
        M[np.ix_(dofs, dofs)] += mass_per_length * shape_integral
    M[0, 0] += cap_mass
    free = np.array([i for i in range(ndof) if i != 1], int)  # fixed head rotation
    Kf = K[np.ix_(free, free)]
    Mf = M[np.ix_(free, free)]
    chol = np.linalg.cholesky(Mf)
    transformed = np.linalg.solve(chol, Kf)
    transformed = np.linalg.solve(chol, transformed.T).T
    eigenvalues, vectors = np.linalg.eigh(transformed)
    keep = np.where(eigenvalues > 1.0e-9)[0][:modes_retained]
    omega = np.sqrt(eigenvalues[keep])
    modes = np.linalg.solve(chol.T, vectors[:, keep])
    influence = np.zeros(ndof)
    influence[0::2] = 1.0
    influence = influence[free]
    participation = modes.T @ Mf @ influence
    head_index = int(np.where(free == 0)[0][0])
    head_modal = modes[head_index, :]
    element_dofs = [0, 1, 2, 3]
    curvature_operator = np.array([-6.0 / le**2, -4.0 / le, 6.0 / le**2, -2.0 / le])
    curvature_modal = np.zeros(modes_retained)
    for local, global_dof in enumerate(element_dofs):
        if global_dof == 1:
            continue
        reduced_index = int(np.where(free == global_dof)[0][0])
        curvature_modal += curvature_operator[local] * modes[reduced_index, :]
    parameters = {
        "pile_length_m": pile_length,
        "diameter_m": diameter,
        "young_modulus_gpa": young / 1.0e9,
        "density_kg_m3": density,
        "cap_mass_kg": cap_mass,
        "active_length_m": active_length,
        "foundation_modulus_n_m2": foundation_modulus,
        "elements": elements,
        "retained_modes": modes_retained,
        "modal_frequencies_hz": "; ".join(f"{x:.3f}" for x in omega / (2.0 * math.pi)),
    }
    return omega, participation, head_modal, curvature_modal, parameters


def modal_newmark(acceleration, dt, omega, participation, head_modal, curvature_modal, damping=0.05):
    beta = 0.25
    gamma = 0.5
    stiffness = omega**2
    viscous = 2.0 * damping * omega
    a0 = 1.0 / (beta * dt**2)
    a1 = gamma / (beta * dt)
    a2 = 1.0 / (beta * dt)
    a3 = 1.0 / (2.0 * beta) - 1.0
    a4 = gamma / beta - 1.0
    a5 = dt * (gamma / (2.0 * beta) - 1.0)
    effective = stiffness + a0 + a1 * viscous
    q = np.zeros_like(omega)
    velocity = np.zeros_like(omega)
    modal_acc = -participation * float(acceleration[0])
    max_head = 0.0
    max_curvature = 0.0
    for ag in acceleration[1:]:
        force = -participation * float(ag)
        effective_force = force + a0 * q + a2 * velocity + a3 * modal_acc + viscous * (
            a1 * q + a4 * velocity + a5 * modal_acc
        )
        q_new = effective_force / effective
        acc_new = a0 * (q_new - q) - a2 * velocity - a3 * modal_acc
        vel_new = velocity + dt * ((1.0 - gamma) * modal_acc + gamma * acc_new)
        q, velocity, modal_acc = q_new, vel_new, acc_new
        max_head = max(max_head, abs(float(head_modal @ q)))
        max_curvature = max(max_curvature, abs(float(curvature_modal @ q)))
    return max_head, max_curvature


def beam_winkler_comparison(feat, fixed_head):
    omega, participation, head_modal, curvature_modal, parameters = build_beam_winkler_modes()
    rows = []
    for rec in feat.itertuples(index=False):
        source = read_waveform(rec)
        t = source.time_s.to_numpy(float)
        acceleration = source.acc_m_s2.to_numpy(float)
        dt = float(np.median(np.diff(t)))
        head, curvature = modal_newmark(acceleration, dt, omega, participation, head_modal, curvature_modal)
        rows.append(
            {
                **{key: getattr(rec, key) for key in KEYS},
                "beam_head_displacement_m": head,
                "beam_head_curvature_1_m": curvature,
                "beam_elastic_predictor_mpa_equiv": ES_PA * YS_M * curvature / 1.0e6,
            }
        )
    out = pd.DataFrame(rows)
    sdof = fixed_head.loc[(fixed_head.damping_ratio.eq(0.05)) & (fixed_head.active_length_m.eq(2.5)), KEYS + ["elastic_predictor_mpa_equiv"]]
    out = out.merge(sdof, on=KEYS)
    top_sdof = set(map(tuple, out.nlargest(10, "elastic_predictor_mpa_equiv")[KEYS].to_numpy()))
    top_beam = set(map(tuple, out.nlargest(10, "beam_elastic_predictor_mpa_equiv")[KEYS].to_numpy()))
    comparison = pd.DataFrame(
        [{
            "spearman_rho_sdof_vs_beam": spearman(out.elastic_predictor_mpa_equiv, out.beam_elastic_predictor_mpa_equiv),
            "top10_overlap": len(top_sdof & top_beam),
            "sdof_top_record": "/".join(out.nlargest(1, "elastic_predictor_mpa_equiv")[KEYS].iloc[0].astype(str)),
            "beam_top_record": "/".join(out.nlargest(1, "beam_elastic_predictor_mpa_equiv")[KEYS].iloc[0].astype(str)),
        }]
    )
    out.to_csv(DATA_DIR / "beam_winkler_modal_comparison.csv", index=False)
    comparison.to_csv(DATA_DIR / "beam_winkler_rank_summary.csv", index=False)
    pd.DataFrame([parameters]).to_csv(DATA_DIR / "beam_winkler_parameters.csv", index=False)
    return out, comparison, parameters


def build_profile_beam_model(
    profile="constant", rotation_ratio=math.inf, modes_retained=3,
    lumped_soil=False, cap_mass=10000.0,
):
    pile_length = 10.0
    diameter = 0.24
    density = 7850.0
    active_length = 2.5
    elements = 20
    area = math.pi * diameter**2 / 4.0
    inertia = math.pi * diameter**4 / 64.0
    ei = ES_PA * inertia
    k0 = 4.0 * ei / active_length**4
    n_h = k0 / active_length
    characteristic_t = (ei / n_h) ** 0.2
    le = pile_length / elements
    ndof = 2 * (elements + 1)
    Kb = np.zeros((ndof, ndof))
    Ks = np.zeros((ndof, ndof))
    M = np.zeros((ndof, ndof))
    kb = ei / le**3 * np.array(
        [[12, 6 * le, -12, 6 * le], [6 * le, 4 * le**2, -6 * le, 2 * le**2],
         [-12, -6 * le, 12, -6 * le], [6 * le, 2 * le**2, -6 * le, 4 * le**2]], float
    )
    mass_shape = le / 420.0 * np.array(
        [[156, 22 * le, 54, -13 * le], [22 * le, 4 * le**2, 13 * le, -3 * le**2],
         [54, 13 * le, 156, -22 * le], [-13 * le, -3 * le**2, -22 * le, 4 * le**2]], float
    )

    def k_at_depth(z):
        if profile == "constant":
            return k0
        if profile == "linear":
            return n_h * z
        raise ValueError(f"Unknown soil profile: {profile}")

    gauss_x, gauss_w = np.polynomial.legendre.leggauss(4)
    for element in range(elements):
        dofs = [2 * element, 2 * element + 1, 2 * element + 2, 2 * element + 3]
        Kb[np.ix_(dofs, dofs)] += kb
        M[np.ix_(dofs, dofs)] += density * area * mass_shape
        if not lumped_soil:
            for gx, gw in zip(gauss_x, gauss_w):
                x = 0.5 * le * (gx + 1.0)
                xi = x / le
                shape = np.array(
                    [1 - 3 * xi**2 + 2 * xi**3, le * (xi - 2 * xi**2 + xi**3),
                     3 * xi**2 - 2 * xi**3, le * (-xi**2 + xi**3)]
                )
                z = element * le + x
                Ks[np.ix_(dofs, dofs)] += k_at_depth(z) * np.outer(shape, shape) * 0.5 * le * gw

    node_depths = np.linspace(0.0, pile_length, elements + 1)
    tributary = np.full(elements + 1, le)
    tributary[[0, -1]] = 0.5 * le
    nodal_soil_stiffness = np.array([k_at_depth(z) for z in node_depths]) * tributary
    if lumped_soil:
        for node, stiffness in enumerate(nodal_soil_stiffness):
            Ks[2 * node, 2 * node] += stiffness

    M[0, 0] += cap_mass
    K = Kb + Ks
    if math.isfinite(rotation_ratio):
        K[1, 1] += rotation_ratio * ei / active_length
        free = np.arange(ndof, dtype=int)
        rotation_stiffness = rotation_ratio * ei / active_length
    else:
        free = np.array([i for i in range(ndof) if i != 1], int)
        rotation_stiffness = math.inf

    Kf = K[np.ix_(free, free)]
    Mf = M[np.ix_(free, free)]
    chol = np.linalg.cholesky(Mf)
    transformed = np.linalg.solve(chol, Kf)
    transformed = np.linalg.solve(chol, transformed.T).T
    transformed = 0.5 * (transformed + transformed.T)
    eigenvalues, vectors = np.linalg.eigh(transformed)
    keep = np.where(eigenvalues > 1.0e-9)[0][:modes_retained]
    omega = np.sqrt(eigenvalues[keep])
    modes = np.linalg.solve(chol.T, vectors[:, keep])
    influence = np.zeros(ndof)
    influence[0::2] = 1.0
    participation = modes.T @ Mf @ influence[free]
    full_modes = np.zeros((ndof, modes_retained))
    full_modes[free, :] = modes
    head_modal = full_modes[0, :]
    curvature_operator = np.array([-6.0 / le**2, -4.0 / le, 6.0 / le**2, -2.0 / le])
    curvature_modal = curvature_operator @ full_modes[[0, 1, 2, 3], :]
    translational_globals = np.arange(0, ndof, 2)
    translational_positions = np.array([int(np.where(free == g)[0][0]) for g in translational_globals])
    parameters = {
        "profile": profile,
        "cap_mass_kg": cap_mass,
        "rotation_ratio_Ktheta_over_EI_by_R": "fixed" if not math.isfinite(rotation_ratio) else rotation_ratio,
        "rotation_stiffness_Nm_per_rad": rotation_stiffness,
        "constant_k_N_m2": k0,
        "linear_nh_N_m3": n_h,
        "linear_characteristic_T_m": characteristic_t,
        "first_mode_hz": omega[0] / (2.0 * math.pi),
        "modal_frequencies_hz": "; ".join(f"{x:.3f}" for x in omega / (2.0 * math.pi)),
        "modes_retained": modes_retained,
        "lumped_soil": lumped_soil,
    }
    return {
        "omega": omega,
        "participation": participation,
        "head_modal": head_modal,
        "curvature_modal": curvature_modal,
        "modes": modes,
        "full_modes": full_modes,
        "free": free,
        "phi_trans": modes[translational_positions, :],
        "nodal_soil_stiffness": nodal_soil_stiffness,
        "diameter": diameter,
        "parameters": parameters,
    }


def beam_profile_boundary_sensitivity(feat):
    scenarios = [
        ("constant_fixed", "constant", math.inf),
        ("linear_fixed", "linear", math.inf),
        ("constant_rot_4", "constant", 4.0),
        ("constant_rot_1", "constant", 1.0),
        ("constant_rot_0p25", "constant", 0.25),
        ("constant_free", "constant", 0.0),
    ]
    rows = []
    parameter_rows = []
    for scenario, profile, rotation_ratio in scenarios:
        model = build_profile_beam_model(profile, rotation_ratio)
        parameter_rows.append({"scenario": scenario, **model["parameters"]})
        for rec in feat.itertuples(index=False):
            source = read_waveform(rec)
            t = source.time_s.to_numpy(float)
            acceleration = source.acc_m_s2.to_numpy(float)
            dt = float(np.median(np.diff(t)))
            head, curvature = modal_newmark(
                acceleration, dt, model["omega"], model["participation"],
                model["head_modal"], model["curvature_modal"]
            )
            rows.append(
                {
                    **{key: getattr(rec, key) for key in KEYS},
                    "scenario": scenario,
                    "soil_profile": profile,
                    "rotation_ratio_Ktheta_over_EI_by_R": "fixed" if not math.isfinite(rotation_ratio) else rotation_ratio,
                    "head_displacement_m": head,
                    "head_curvature_1_m": curvature,
                    "beam_curvature_ductility": curvature / KAPPA_Y_1_M,
                }
            )
    detail = pd.DataFrame(rows)
    base = detail.loc[detail.scenario.eq("constant_fixed"), KEYS + ["head_curvature_1_m"]].rename(
        columns={"head_curvature_1_m": "base_curvature_1_m"}
    )
    base_top = set(map(tuple, detail.loc[detail.scenario.eq("constant_fixed")].nlargest(10, "head_curvature_1_m")[KEYS].to_numpy()))
    summary_rows = []
    for scenario, frame in detail.groupby("scenario", sort=False):
        joined = frame.merge(base, on=KEYS)
        top = set(map(tuple, joined.nlargest(10, "head_curvature_1_m")[KEYS].to_numpy()))
        ratios = joined.head_curvature_1_m / joined.base_curvature_1_m.replace(0.0, np.nan)
        pars = next(row for row in parameter_rows if row["scenario"] == scenario)
        summary_rows.append(
            {
                "scenario": scenario,
                "soil_profile": pars["profile"],
                "rotation_ratio_Ktheta_over_EI_by_R": pars["rotation_ratio_Ktheta_over_EI_by_R"],
                "first_mode_hz": pars["first_mode_hz"],
                "spearman_rho_vs_constant_fixed": spearman(joined.base_curvature_1_m, joined.head_curvature_1_m),
                "top10_overlap": len(base_top & top),
                "median_curvature_ratio_vs_constant_fixed": float(ratios.median()),
                "q10_curvature_ratio": float(ratios.quantile(0.10)),
                "q90_curvature_ratio": float(ratios.quantile(0.90)),
                "top_record": "/".join(joined.nlargest(1, "head_curvature_1_m")[KEYS].iloc[0].astype(str)),
            }
        )
    summary = pd.DataFrame(summary_rows)
    detail.to_csv(DATA_DIR / "beam_boundary_soil_sensitivity.csv", index=False)
    summary.to_csv(DATA_DIR / "beam_boundary_soil_summary.csv", index=False)
    pd.DataFrame(parameter_rows).to_csv(DATA_DIR / "beam_boundary_soil_parameters.csv", index=False)
    return detail, summary


def cap_mass_sensitivity(feat):
    masses = [2500.0, 5000.0, 10000.0]
    rows = []
    parameter_rows = []
    for cap_mass in masses:
        model = build_profile_beam_model("constant", math.inf, cap_mass=cap_mass)
        parameter_rows.append({"cap_mass_kg": cap_mass, **model["parameters"]})
        for rec in feat.itertuples(index=False):
            source = read_waveform(rec)
            time = source.time_s.to_numpy(float)
            acceleration = source.acc_m_s2.to_numpy(float)
            dt = float(np.median(np.diff(time)))
            head, curvature = modal_newmark(
                acceleration, dt, model["omega"], model["participation"],
                model["head_modal"], model["curvature_modal"]
            )
            rows.append(
                {
                    **{key: getattr(rec, key) for key in KEYS},
                    "cap_mass_kg": cap_mass,
                    "head_displacement_m": head,
                    "head_curvature_1_m": curvature,
                    "beam_curvature_ductility": curvature / KAPPA_Y_1_M,
                }
            )
    detail = pd.DataFrame(rows)
    base = detail.loc[detail.cap_mass_kg.eq(10000.0), KEYS + ["head_curvature_1_m"]].rename(
        columns={"head_curvature_1_m": "base_curvature_1_m"}
    )
    base_top = set(map(tuple, detail.loc[detail.cap_mass_kg.eq(10000.0)].nlargest(10, "head_curvature_1_m")[KEYS].to_numpy()))
    summary_rows = []
    for cap_mass, frame in detail.groupby("cap_mass_kg", sort=True):
        joined = frame.merge(base, on=KEYS)
        top = set(map(tuple, joined.nlargest(10, "head_curvature_1_m")[KEYS].to_numpy()))
        ratios = joined.head_curvature_1_m / joined.base_curvature_1_m.replace(0.0, np.nan)
        parameters = next(row for row in parameter_rows if row["cap_mass_kg"] == cap_mass)
        summary_rows.append(
            {
                "cap_mass_kg": cap_mass,
                "modal_frequencies_hz": parameters["modal_frequencies_hz"],
                "first_mode_hz": parameters["first_mode_hz"],
                "spearman_rho_vs_10000kg": spearman(joined.base_curvature_1_m, joined.head_curvature_1_m),
                "top10_overlap_vs_10000kg": len(base_top & top),
                "median_curvature_ratio_vs_10000kg": float(ratios.median()),
                "q10_curvature_ratio": float(ratios.quantile(0.10)),
                "q90_curvature_ratio": float(ratios.quantile(0.90)),
                "top_record": "/".join(joined.nlargest(1, "head_curvature_1_m")[KEYS].iloc[0].astype(str)),
            }
        )
    summary = pd.DataFrame(summary_rows)
    detail.to_csv(DATA_DIR / "cap_mass_sensitivity.csv", index=False)
    summary.to_csv(DATA_DIR / "cap_mass_sensitivity_summary.csv", index=False)
    pd.DataFrame(parameter_rows).to_csv(DATA_DIR / "cap_mass_parameters.csv", index=False)
    return detail, summary


def ranked_multimodel_suite(feat, fixed_head, beam_sensitivity, cap_mass_detail):
    sdof = fixed_head.loc[
        fixed_head.damping_ratio.eq(0.05) & fixed_head.active_length_m.eq(2.5),
        KEYS + ["curvature_ductility"],
    ].rename(columns={"curvature_ductility": "sdof_mu_phi"})
    pivot = beam_sensitivity.pivot_table(index=KEYS, columns="scenario", values="beam_curvature_ductility").reset_index()
    pivot = pivot.rename(
        columns={
            "constant_fixed": "beam_constant_fixed_mu_phi",
            "linear_fixed": "beam_linear_fixed_mu_phi",
            "constant_rot_1": "beam_rotational_mu_phi",
        }
    )
    mass_pivot = cap_mass_detail.pivot_table(
        index=KEYS, columns="cap_mass_kg", values="beam_curvature_ductility"
    ).reset_index().rename(
        columns={
            2500.0: "beam_mass_2500_mu_phi",
            5000.0: "beam_mass_5000_mu_phi",
            10000.0: "beam_mass_10000_mu_phi",
        }
    )
    out = feat[KEYS + ["orientation", "pga_g", "stmoi"]].merge(sdof, on=KEYS).merge(pivot, on=KEYS).merge(mass_pivot, on=KEYS)
    metrics = [
        "stmoi", "sdof_mu_phi", "beam_mass_2500_mu_phi", "beam_mass_5000_mu_phi",
        "beam_mass_10000_mu_phi", "beam_linear_fixed_mu_phi", "beam_rotational_mu_phi",
    ]
    rank_columns = []
    for metric in metrics:
        rank_name = metric + "_rank"
        out[rank_name] = out[metric].rank(method="min", ascending=False).astype(int)
        rank_columns.append(rank_name)
    out["consensus_mean_rank"] = out[rank_columns].mean(axis=1)
    out["consensus_rank"] = out.consensus_mean_rank.rank(method="min", ascending=True).astype(int)
    out = out.sort_values(["consensus_rank", "stmoi_rank"])
    out.to_csv(DATA_DIR / "ranked_multimodel_suite.csv", index=False)
    return out


def common_pga_scaling_sensitivity(feat, ranked_suite, target_pga_g=0.40):
    scaled = feat[KEYS + [
        "orientation", "pga_g", "rms_g", "cav_g_s", "arias_m_s", "d5_95_s",
        "sensor_band_0p5_15_fraction", "stmoi",
    ]].copy()
    scaled["amplitude_scale_factor"] = target_pga_g / scaled.pga_g
    scaled["pga_g_scaled"] = target_pga_g
    scaled["rms_g_scaled"] = scaled.rms_g * scaled.amplitude_scale_factor
    scaled["cav_g_s_scaled"] = scaled.cav_g_s * scaled.amplitude_scale_factor
    scaled["arias_m_s_scaled"] = scaled.arias_m_s * scaled.amplitude_scale_factor**2
    scaled["d5_95_s_scaled"] = scaled.d5_95_s
    raw_scaled = ["pga_g_scaled", "rms_g_scaled", "cav_g_s_scaled", "arias_m_s_scaled", "d5_95_s_scaled"]
    for name in raw_scaled:
        scaled[name + "_norm"] = scaled[name] / float(scaled[name].max())
    scaled["component_factor"] = np.where(scaled.orientation.eq("Vertical"), 1.0, 0.9)
    scaled["sensor_band"] = scaled.sensor_band_0p5_15_fraction
    scaled["stmoi_scaled"] = (
        0.25 * scaled.pga_g_scaled_norm
        + 0.20 * scaled.rms_g_scaled_norm
        + 0.15 * scaled.cav_g_s_scaled_norm
        + 0.15 * scaled.arias_m_s_scaled_norm
        + 0.10 * scaled.d5_95_s_scaled_norm
        + 0.10 * scaled.sensor_band
        + 0.05 * scaled.component_factor
    )
    scaled["unscaled_stmoi_rank"] = scaled.stmoi.rank(method="min", ascending=False).astype(int)
    scaled["scaled_stmoi_rank"] = scaled.stmoi_scaled.rank(method="min", ascending=False).astype(int)

    mechanical_columns = [
        "sdof_mu_phi", "beam_mass_2500_mu_phi", "beam_mass_5000_mu_phi",
        "beam_mass_10000_mu_phi", "beam_linear_fixed_mu_phi", "beam_rotational_mu_phi",
    ]
    suite_columns = KEYS + mechanical_columns + ["consensus_rank"]
    scaled = scaled.merge(ranked_suite[suite_columns], on=KEYS)
    for name in mechanical_columns:
        scaled[name + "_scaled"] = scaled[name] * scaled.amplitude_scale_factor
    ranking_metrics = ["stmoi_scaled"] + [name + "_scaled" for name in mechanical_columns]
    rank_columns = []
    for metric in ranking_metrics:
        rank_name = metric + "_rank"
        scaled[rank_name] = scaled[metric].rank(method="min", ascending=False).astype(int)
        rank_columns.append(rank_name)
    scaled["scaled_consensus_mean_rank"] = scaled[rank_columns].mean(axis=1)
    scaled["scaled_consensus_rank"] = scaled.scaled_consensus_mean_rank.rank(method="min", ascending=True).astype(int)
    scaled = scaled.sort_values(["scaled_consensus_rank", "scaled_stmoi_rank"])

    unscaled_top10 = set(map(tuple, ranked_suite.nsmallest(10, "consensus_rank")[KEYS].to_numpy()))
    scaled_top10 = set(map(tuple, scaled.nsmallest(10, "scaled_consensus_rank")[KEYS].to_numpy()))
    unscaled_stmoi_top10 = set(map(tuple, feat.nlargest(10, "stmoi")[KEYS].to_numpy()))
    scaled_stmoi_top10 = set(map(tuple, scaled.nlargest(10, "stmoi_scaled")[KEYS].to_numpy()))
    summary = pd.DataFrame(
        [{
            "target_pga_g": target_pga_g,
            "stmoi_spearman_rho": spearman(scaled.stmoi, scaled.stmoi_scaled),
            "stmoi_top10_overlap": len(unscaled_stmoi_top10 & scaled_stmoi_top10),
            "consensus_spearman_rho": spearman(scaled.consensus_rank, scaled.scaled_consensus_rank),
            "consensus_top10_overlap": len(unscaled_top10 & scaled_top10),
            "unscaled_consensus_top_record": "/".join(ranked_suite.nsmallest(1, "consensus_rank")[KEYS].iloc[0].astype(str)),
            "scaled_consensus_top_record": "/".join(scaled.nsmallest(1, "scaled_consensus_rank")[KEYS].iloc[0].astype(str)),
            "minimum_scale_factor": scaled.amplitude_scale_factor.min(),
            "maximum_scale_factor": scaled.amplitude_scale_factor.max(),
        }]
    )
    scaled.to_csv(DATA_DIR / "common_pga_scaled_ranking.csv", index=False)
    summary.to_csv(DATA_DIR / "common_pga_scaling_summary.csv", index=False)
    return scaled, summary


def nonlinear_modal_newmark(acceleration, dt, model, y50, damping=0.05, max_iterations=15):
    omega = model["omega"]
    participation = model["participation"]
    phi_trans = model["phi_trans"]
    k_node = model["nodal_soil_stiffness"]
    curvature_modal = model["curvature_modal"]
    head_modal = model["head_modal"]
    active = k_node > 0.0
    pult = np.zeros_like(k_node)
    pult[active] = k_node[active] * y50 / np.arctanh(0.5)
    beta = 0.25
    gamma = 0.5
    a0 = 1.0 / (beta * dt**2)
    a1 = gamma / (beta * dt)
    a2 = 1.0 / (beta * dt)
    a3 = 1.0 / (2.0 * beta) - 1.0
    viscous = np.diag(2.0 * damping * omega)
    stiffness = np.diag(omega**2)
    identity = np.eye(len(omega))
    q = np.zeros_like(omega)
    velocity = np.zeros_like(omega)
    modal_acc = -participation * float(acceleration[0])
    max_curvature = 0.0
    max_head = 0.0
    max_y_over_y50 = 0.0
    failed_steps = 0

    def correction(state):
        y = phi_trans @ state
        force = np.zeros_like(y)
        tangent = np.zeros_like(y)
        argument = np.zeros_like(y)
        argument[active] = k_node[active] * y[active] / pult[active]
        force[active] = pult[active] * np.tanh(argument[active])
        tangent[active] = k_node[active] / np.cosh(np.clip(argument[active], -30.0, 30.0)) ** 2
        delta_force = force - k_node * y
        generalized = phi_trans.T @ delta_force
        tangent_correction = phi_trans.T @ ((tangent - k_node)[:, None] * phi_trans)
        return generalized, tangent_correction, y

    for ag in acceleration[1:]:
        q_trial = q + dt * velocity + dt**2 * (0.5 - beta) * modal_acc
        converged = False
        for _ in range(max_iterations):
            acc_trial = a0 * (q_trial - q) - a2 * velocity - a3 * modal_acc
            vel_trial = velocity + dt * ((1.0 - gamma) * modal_acc + gamma * acc_trial)
            nonlinear_force, nonlinear_tangent, physical_y = correction(q_trial)
            residual = acc_trial + viscous @ vel_trial + stiffness @ q_trial + nonlinear_force + participation * float(ag)
            tangent = a0 * identity + a1 * viscous + stiffness + nonlinear_tangent
            increment = np.linalg.solve(tangent, -residual)
            q_trial += increment
            if np.linalg.norm(increment) <= 1.0e-9 * (1.0 + np.linalg.norm(q_trial)):
                converged = True
                break
        if not converged:
            failed_steps += 1
        acc_new = a0 * (q_trial - q) - a2 * velocity - a3 * modal_acc
        vel_new = velocity + dt * ((1.0 - gamma) * modal_acc + gamma * acc_new)
        q, velocity, modal_acc = q_trial, vel_new, acc_new
        y = phi_trans @ q
        max_curvature = max(max_curvature, abs(float(curvature_modal @ q)))
        max_head = max(max_head, abs(float(head_modal @ q)))
        max_y_over_y50 = max(max_y_over_y50, float(np.max(np.abs(y))) / y50)
    return max_head, max_curvature, max_y_over_y50, failed_steps


def nonlinear_py_sensitivity(feat, fixed_head):
    baseline = fixed_head.loc[
        fixed_head.damping_ratio.eq(0.05) & fixed_head.active_length_m.eq(2.5)
    ].nlargest(5, "curvature_ductility")
    model = build_profile_beam_model("linear", math.inf, lumped_soil=True)
    rows = []
    for rec in baseline.itertuples(index=False):
        source_record = feat.merge(
            pd.DataFrame([{key: getattr(rec, key) for key in KEYS}]), on=KEYS
        ).iloc[0]
        source = read_waveform(source_record)
        t = source.time_s.to_numpy(float)
        acceleration = source.acc_m_s2.to_numpy(float)
        dt = float(np.median(np.diff(t)))
        linear_head, linear_curvature = modal_newmark(
            acceleration, dt, model["omega"], model["participation"], model["head_modal"], model["curvature_modal"]
        )
        for ratio in [0.005, 0.010, 0.020]:
            y50 = ratio * model["diameter"]
            head, curvature, max_y_ratio, failed = nonlinear_modal_newmark(acceleration, dt, model, y50)
            rows.append(
                {
                    **{key: getattr(rec, key) for key in KEYS},
                    "y50_over_diameter": ratio,
                    "y50_m": y50,
                    "linear_head_displacement_m": linear_head,
                    "nonlinear_head_displacement_m": head,
                    "linear_curvature_1_m": linear_curvature,
                    "nonlinear_curvature_1_m": curvature,
                    "linear_mu_phi": linear_curvature / KAPPA_Y_1_M,
                    "nonlinear_mu_phi": curvature / KAPPA_Y_1_M,
                    "nonlinear_to_linear_curvature_ratio": curvature / linear_curvature if linear_curvature else np.nan,
                    "maximum_nodal_displacement_over_y50": max_y_ratio,
                    "nonconverged_steps": failed,
                }
            )
    detail = pd.DataFrame(rows)
    summary_rows = []
    for ratio, frame in detail.groupby("y50_over_diameter"):
        summary_rows.append(
            {
                "y50_over_diameter": ratio,
                "records": len(frame),
                "median_nonlinear_to_linear_curvature_ratio": frame.nonlinear_to_linear_curvature_ratio.median(),
                "minimum_ratio": frame.nonlinear_to_linear_curvature_ratio.min(),
                "maximum_ratio": frame.nonlinear_to_linear_curvature_ratio.max(),
                "spearman_rho_linear_vs_nonlinear": spearman(frame.linear_curvature_1_m, frame.nonlinear_curvature_1_m),
                "maximum_nonconverged_steps": int(frame.nonconverged_steps.max()),
            }
        )
    summary = pd.DataFrame(summary_rows)
    detail.to_csv(DATA_DIR / "illustrative_nonlinear_py_sensitivity.csv", index=False)
    summary.to_csv(DATA_DIR / "illustrative_nonlinear_py_summary.csv", index=False)
    return detail, summary


def hierarchical_bootstrap(feat, fixed_head, iterations=2000, seed=23032026):
    baseline = fixed_head.loc[(fixed_head.damping_ratio.eq(0.05)) & (fixed_head.active_length_m.eq(2.5)), KEYS + ["elastic_predictor_mpa_equiv"]]
    frame = feat.merge(baseline, on=KEYS)
    rng = np.random.default_rng(seed)
    grouped = {}
    for event, event_frame in frame.groupby("event_id"):
        grouped[event] = [
            station_frame[["stmoi", "elastic_predictor_mpa_equiv"]].to_numpy(float)
            for _, station_frame in event_frame.groupby("station")
        ]
    events = np.array(sorted(grouped), object)

    def fast_rho(sample):
        x = sample[:, 0]
        y = sample[:, 1]
        rx = np.empty(len(x), float)
        ry = np.empty(len(y), float)
        rx[np.argsort(x, kind="mergesort")] = np.arange(len(x), dtype=float)
        ry[np.argsort(y, kind="mergesort")] = np.arange(len(y), dtype=float)
        return float(np.corrcoef(rx, ry)[0, 1])

    rhos = []
    for _ in range(iterations):
        sampled_parts = []
        for event in rng.choice(events, size=len(events), replace=True):
            stations = grouped[event]
            for station_index in rng.integers(0, len(stations), size=len(stations)):
                sampled_parts.append(stations[int(station_index)])
        sample = np.vstack(sampled_parts)
        rhos.append(fast_rho(sample))
    values = np.asarray(rhos)
    summary = pd.DataFrame(
        [{
            "iterations": iterations,
            "median_rho": float(np.median(values)),
            "q025_rho": float(np.quantile(values, 0.025)),
            "q25_rho": float(np.quantile(values, 0.25)),
            "q75_rho": float(np.quantile(values, 0.75)),
            "q975_rho": float(np.quantile(values, 0.975)),
        }]
    )
    pd.DataFrame({"bootstrap_rho": values}).to_csv(DATA_DIR / "hierarchical_bootstrap_rho.csv", index=False)
    summary.to_csv(DATA_DIR / "hierarchical_bootstrap_summary.csv", index=False)
    return summary


def uncertainty_propagation(maxima, iterations=5000, seed=25032026):
    pivot = maxima.pivot_table(index=KEYS, columns="damping_ratio", values="max_relative_displacement_m")
    pivot = pivot.sort_index()
    rng = np.random.default_rng(seed)
    damping = rng.uniform(0.05, 0.15, iterations)
    active_length = rng.uniform(1.5, 3.5, iterations)
    values = pivot[[0.05, 0.10, 0.15]].to_numpy(float)
    displacement = np.empty((len(pivot), iterations), float)
    low = damping <= 0.10
    displacement[:, low] = values[:, [0]] + (values[:, [1]] - values[:, [0]]) * ((damping[low] - 0.05) / 0.05)
    displacement[:, ~low] = values[:, [1]] + (values[:, [2]] - values[:, [1]]) * ((damping[~low] - 0.10) / 0.05)
    stress = 2.0 * ES_PA * YS_M * displacement / active_length[np.newaxis, :] ** 2 / 1.0e6
    top10_counts = np.zeros(len(pivot), int)
    for column in range(iterations):
        top = np.argpartition(stress[:, column], -10)[-10:]
        top10_counts[top] += 1
    summary = pd.DataFrame(list(pivot.index), columns=KEYS)
    summary["q25_mpa_equiv"] = np.quantile(stress, 0.25, axis=1)
    summary["median_mpa_equiv"] = np.median(stress, axis=1)
    summary["q75_mpa_equiv"] = np.quantile(stress, 0.75, axis=1)
    summary["p95_mpa_equiv"] = np.quantile(stress, 0.95, axis=1)
    summary["top10_probability"] = top10_counts / iterations
    summary = summary.sort_values("median_mpa_equiv", ascending=False)
    summary.to_csv(DATA_DIR / "joint_uncertainty_summary.csv", index=False)
    pd.DataFrame({"damping_ratio": damping, "active_length_m": active_length}).to_csv(
        DATA_DIR / "joint_uncertainty_samples.csv", index=False
    )
    return summary


def nonlinear_triage(fixed_head):
    baseline = fixed_head.loc[(fixed_head.damping_ratio.eq(0.05)) & (fixed_head.active_length_m.eq(2.5))].nlargest(5, "curvature_ductility").copy()
    yield_displacement = FY_MPA * 1.0e6 * 2.5**2 / (2.0 * ES_PA * YS_M)
    baseline["fixed_head_yield_displacement_m"] = yield_displacement
    baseline["displacement_to_yield_ratio"] = baseline.max_relative_displacement_m / yield_displacement
    baseline["required_next_analysis"] = "Site-calibrated OpenSees PySimple1/TzSimple1 model with steel moment-curvature law"
    baseline.to_csv(DATA_DIR / "governing_nonlinear_analysis.csv", index=False)
    return baseline


def write_summary(
    feat, fixed_head, loeo, dep, orient, transfer, beam_summary, bootstrap, uncertainty, triage,
    boundary_summary, ranked_suite, nonlinear_summary, cap_mass_summary, scaling_summary,
):
    baseline = fixed_head.loc[(fixed_head.damping_ratio.eq(0.05)) & (fixed_head.active_length_m.eq(2.5))]
    event_icc = dep.loc[(dep.cluster_level.eq("Event")) & (dep.metric.eq("stmoi"))].iloc[0]
    station_icc = dep.loc[(dep.cluster_level.eq("Event-station")) & (dep.metric.eq("stmoi"))].iloc[0]
    rows = {
        "component_count": len(feat),
        "event_count": feat.event_id.nunique(),
        "station_count": feat[["event_id", "station"]].drop_duplicates().shape[0],
        "max_mpa_equiv_R2p5_zeta5": baseline.elastic_predictor_mpa_equiv.max(),
        "records_above_yield_R2p5_zeta5": int((baseline.elastic_predictor_mpa_equiv > FY_MPA).sum()),
        "loeo_min_rho": loeo.spearman_rho.min(),
        "loeo_min_top10_overlap": loeo.top10_overlap.min(),
        "event_icc_stmoi": event_icc.icc_1,
        "event_effective_n_stmoi": event_icc.effective_n,
        "station_icc_stmoi": station_icc.icc_1,
        "station_effective_n_stmoi": station_icc.effective_n,
        "orientation_binary_rho": orient.loc[orient.horizontal_factor.eq(0.0), "spearman_rho_vs_base"].iloc[0],
        "orientation_binary_top10_overlap": int(orient.loc[orient.horizontal_factor.eq(0.0), "top10_overlap"].iloc[0]),
        "transfer_min_rho": transfer.spearman_rho_vs_rectangular_base.min(),
        "transfer_min_top10_overlap": transfer.top10_overlap.min(),
        "beam_vs_sdof_rho": beam_summary.spearman_rho_sdof_vs_beam.iloc[0],
        "beam_vs_sdof_top10_overlap": int(beam_summary.top10_overlap.iloc[0]),
        "linear_profile_rho_vs_constant_fixed": boundary_summary.loc[
            boundary_summary.scenario.eq("linear_fixed"), "spearman_rho_vs_constant_fixed"
        ].iloc[0],
        "linear_profile_top10_overlap": int(boundary_summary.loc[
            boundary_summary.scenario.eq("linear_fixed"), "top10_overlap"
        ].iloc[0]),
        "rotation_ratio_1_rho_vs_fixed": boundary_summary.loc[
            boundary_summary.scenario.eq("constant_rot_1"), "spearman_rho_vs_constant_fixed"
        ].iloc[0],
        "rotation_ratio_1_top10_overlap": int(boundary_summary.loc[
            boundary_summary.scenario.eq("constant_rot_1"), "top10_overlap"
        ].iloc[0]),
        "ranked_suite_top_record": "/".join(ranked_suite.iloc[0][KEYS].astype(str)),
        "cap_mass_2500_first_mode_hz": cap_mass_summary.loc[cap_mass_summary.cap_mass_kg.eq(2500.0), "first_mode_hz"].iloc[0],
        "cap_mass_5000_first_mode_hz": cap_mass_summary.loc[cap_mass_summary.cap_mass_kg.eq(5000.0), "first_mode_hz"].iloc[0],
        "cap_mass_10000_first_mode_hz": cap_mass_summary.loc[cap_mass_summary.cap_mass_kg.eq(10000.0), "first_mode_hz"].iloc[0],
        "cap_mass_min_rho_vs_10000kg": cap_mass_summary.spearman_rho_vs_10000kg.min(),
        "cap_mass_min_top10_overlap_vs_10000kg": int(cap_mass_summary.top10_overlap_vs_10000kg.min()),
        "common_pga_target_g": scaling_summary.target_pga_g.iloc[0],
        "common_pga_stmoi_rho": scaling_summary.stmoi_spearman_rho.iloc[0],
        "common_pga_stmoi_top10_overlap": int(scaling_summary.stmoi_top10_overlap.iloc[0]),
        "common_pga_consensus_rho": scaling_summary.consensus_spearman_rho.iloc[0],
        "common_pga_consensus_top10_overlap": int(scaling_summary.consensus_top10_overlap.iloc[0]),
        "common_pga_scaled_top_record": scaling_summary.scaled_consensus_top_record.iloc[0],
        "nonlinear_py_min_median_ratio": nonlinear_summary.median_nonlinear_to_linear_curvature_ratio.min(),
        "nonlinear_py_max_median_ratio": nonlinear_summary.median_nonlinear_to_linear_curvature_ratio.max(),
        "nonlinear_py_max_failed_steps": int(nonlinear_summary.maximum_nonconverged_steps.max()),
        "bootstrap_median_rho": bootstrap.median_rho.iloc[0],
        "bootstrap_95_low": bootstrap.q025_rho.iloc[0],
        "bootstrap_95_high": bootstrap.q975_rho.iloc[0],
        "uncertainty_top_record": "/".join(uncertainty.iloc[0][KEYS].astype(str)),
        "uncertainty_top_median_mpa_equiv": uncertainty.iloc[0].median_mpa_equiv,
        "triage_all_top5_mandatory": bool(triage.nonlinear_follow_up.eq("Mandatory").all()),
    }
    pd.DataFrame([{"metric": key, "value": value} for key, value in rows.items()]).to_csv(
        DATA_DIR / "analysis_summary.csv", index=False
    )


def main():
    feat = pd.read_csv(FEATURE_FILE)
    dynamic = pd.read_csv(DYNAMIC_FILE)
    supplementary_component_inventory(feat)
    fixed_head, maxima = fixed_head_response(dynamic, feat)
    loeo = leave_one_event_out(feat)
    dep = dependence_diagnostics(feat)
    orient = orientation_sensitivity(feat)
    transfer, _ = transfer_function_sensitivity(feat)
    beam, beam_summary, parameters = beam_winkler_comparison(feat, fixed_head)
    boundary_detail, boundary_summary = beam_profile_boundary_sensitivity(feat)
    cap_mass_detail, cap_mass_summary = cap_mass_sensitivity(feat)
    ranked_suite = ranked_multimodel_suite(feat, fixed_head, boundary_detail, cap_mass_detail)
    scaled_ranking, scaling_summary = common_pga_scaling_sensitivity(feat, ranked_suite)
    nonlinear_detail, nonlinear_summary = nonlinear_py_sensitivity(feat, fixed_head)
    bootstrap = hierarchical_bootstrap(feat, fixed_head)
    uncertainty = uncertainty_propagation(maxima)
    triage = nonlinear_triage(fixed_head)
    write_summary(
        feat, fixed_head, loeo, dep, orient, transfer, beam_summary, bootstrap, uncertainty, triage,
        boundary_summary, ranked_suite, nonlinear_summary, cap_mass_summary, scaling_summary,
    )
    print("Analysis complete")
    print(pd.read_csv(DATA_DIR / "analysis_summary.csv").to_string(index=False))
    print("Beam parameters", parameters)


if __name__ == "__main__":
    main()
