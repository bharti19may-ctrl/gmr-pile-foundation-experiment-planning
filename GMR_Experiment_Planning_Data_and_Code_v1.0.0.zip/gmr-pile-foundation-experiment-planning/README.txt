REPRODUCIBILITY SUPPLEMENT

Repository
https://github.com/bharti19may-ctrl/gmr-pile-foundation-experiment-planning

Scope
This package contains the derived inputs, numerical result tables, analysis
code and component inventory supporting the study. The calculations are
intended for record screening and experimental planning; they do not constitute
site-specific foundation design or calibrated GMR response prediction.

Source data
The original processed acceleration histories are publicly available from the
Center for Engineering Strong Motion Data (CESMD), operated by the USGS and the
California Geological Survey, at https://www.strongmotioncenter.org/. The
waveforms are not redistributed in this package. The event, station and
component identifiers required to retrieve them are listed in Supplementary
Table S1 and data/inputs/component_feature_matrix_81.csv.

Package contents
- DATA_AVAILABILITY_STATEMENT.txt: repository-linked data availability statement.
- MANIFEST_SHA256.txt: file sizes and SHA-256 checksums.
- tables/Table_S1_Component_Inventory.docx: formatted 81-component inventory.
- data/inputs/component_feature_matrix_81.csv: component-level input and feature
  matrix with portable waveform locations.
- data/inputs/dynamic_response_matrix.csv: SDOF response input used in the
  fixed-head screening calculations.
- data/inputs/stmoi_weight_sensitivity.csv: ST-MOI weight perturbations.
- data/results/: derived CSV result tables reported or summarized in the study.
- scripts/analysis_workflow.py: portable analysis code.
- scripts/verify_supplement.py: package-integrity and data-quality checks that do
  not require the original waveforms.

Package verification
From the package root, run:

  python scripts/verify_supplement.py

The verification checks package completeness, the 81-component data structure,
unique component keys, finite required variables, dynamic-response key coverage,
result-file presence, portable paths and manifest integrity. It does not
download source waveforms.

Reproducing the numerical analysis
1. Retrieve the processed acceleration histories identified in Supplementary
   Table S1 from CESMD.
2. Place each waveform CSV under:

   data/waveforms/<event_id>/<station>/<original_filename>.csv

   Alternatively, set CESMD_WAVEFORM_ROOT to a directory containing the same
   event/station/file hierarchy.
3. Each waveform CSV must contain the columns time_s, acc_g and acc_m_s2.
4. Use Python 3 with numpy and pandas installed.
5. Run:

   python scripts/analysis_workflow.py

Outputs are written to data/reproduced_results so the reference result tables
remain available for comparison.

Interpretation limits
- The 81 components are clustered within 27 event-station pairs and five
  earthquakes; they are not 81 independent earthquake observations.
- The hyperbolic p-y calculation is an illustrative model-form diagnostic and
  excludes cyclic degradation, liquefaction and calibrated radiation damping.
- GMR planning quantities are not voltage, resistance, flux density or stress.
- No empirical dynamic GMR-on-steel measurement dataset was analysed.
